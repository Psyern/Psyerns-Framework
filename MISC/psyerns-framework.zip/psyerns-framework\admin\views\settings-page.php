<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap pf-admin-wrap">
	<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>

	<div class="pf-setup-guide" style="background:#fff;border-left:4px solid #2271b1;padding:12px 16px;margin:16px 0;box-shadow:0 1px 1px rgba(0,0,0,.04);">
		<h3 style="margin-top:0;"><?php esc_html_e( 'Quick Setup Guide', 'psyerns-framework' ); ?></h3>
		<ol style="margin-left:18px;">
			<li><?php echo wp_kses_post( __( 'Set an API Key below — or leave it empty and let the DayZ server auto-generate one on first start (check the server log for the generated key).', 'psyerns-framework' ) ); ?></li>
			<li><?php echo wp_kses_post( __( 'Enter the same API Key in your DayZ server config: <code>PsyernsFrameworkConfig.json</code> → WordPress Endpoint → ApiKey.', 'psyerns-framework' ) ); ?></li>
			<li><?php echo wp_kses_post( sprintf(
				__( 'Set your WordPress URL in the DayZ config: <code>BaseUrl</code> → <code>%s</code>', 'psyerns-framework' ),
				esc_url( rest_url( 'psyern/v1' ) )
			) ); ?></li>
			<li><?php esc_html_e( 'Enable the WordPress endpoint in the DayZ config and restart the server.', 'psyerns-framework' ); ?></li>
			<li><?php esc_html_e( 'Test the connection with the Ping URL below.', 'psyerns-framework' ); ?></li>
		</ol>
	</div>

	<?php
	$api_key  = get_option( 'pf_api_key', '' );
	$ping_url = rest_url( 'psyern/v1/ping' );
	if ( ! empty( $api_key ) ) {
		$ping_url .= '?api_key=' . $api_key;
	}
	?>
	<div class="pf-connection-test" style="background:#fff;border-left:4px solid #00a32a;padding:12px 16px;margin:16px 0;box-shadow:0 1px 1px rgba(0,0,0,.04);">
		<h3 style="margin-top:0;"><?php esc_html_e( 'Connection Test', 'psyerns-framework' ); ?></h3>
		<p><?php esc_html_e( 'Use this URL to test if the API is reachable. Expected response:', 'psyerns-framework' ); ?> <code>{"status":"ok"}</code></p>
		<p>
			<strong><?php esc_html_e( 'Ping URL:', 'psyerns-framework' ); ?></strong><br>
			<code style="display:inline-block;padding:6px 10px;background:#f0f0f1;border-radius:3px;word-break:break-all;user-select:all;"><?php echo esc_html( $ping_url ); ?></code>
			<a href="<?php echo esc_url( $ping_url ); ?>" target="_blank" class="button button-secondary" style="margin-left:8px;"><?php esc_html_e( 'Test Now', 'psyerns-framework' ); ?></a>
		</p>
		<?php if ( empty( $api_key ) ) : ?>
			<p style="color:#d63638;"><strong><?php esc_html_e( 'API Key is not set yet. Save your settings first.', 'psyerns-framework' ); ?></strong></p>
		<?php endif; ?>
	</div>

	<div class="pf-shortcodes-info" style="background:#fff;border-left:4px solid #8c8f94;padding:12px 16px;margin:16px 0;box-shadow:0 1px 1px rgba(0,0,0,.04);">
		<h3 style="margin-top:0;"><?php esc_html_e( 'Available Shortcodes', 'psyerns-framework' ); ?></h3>
		<table class="widefat" style="max-width:600px;">
			<tbody>
				<tr><td><code>[pf_leaderboard]</code></td><td><?php esc_html_e( 'Full leaderboard with PvE/PvP tabs', 'psyerns-framework' ); ?></td></tr>
				<tr><td><code>[pf_server_status]</code></td><td><?php esc_html_e( 'Current server status widget', 'psyerns-framework' ); ?></td></tr>
				<tr><td><code>[pf_top3_monthly]</code></td><td><?php esc_html_e( 'Top 3 players of the month', 'psyerns-framework' ); ?></td></tr>
				<tr><td><code>[pf_top3_deadliest]</code></td><td><?php esc_html_e( 'Top 3 deadliest players', 'psyerns-framework' ); ?></td></tr>
				<tr><td><code>[pf_top3_bosskills]</code></td><td><?php esc_html_e( 'Top 3 boss slayers', 'psyerns-framework' ); ?></td></tr>
				<tr><td><code>[pf_player_card steam_id="..."]</code></td><td><?php esc_html_e( 'Single player stats card', 'psyerns-framework' ); ?></td></tr>
			</tbody>
		</table>
		<p class="description"><?php echo wp_kses_post( __( 'Optional attributes: <code>theme="dark"</code> or <code>theme="light"</code>, <code>type="pve"</code> or <code>type="pvp"</code>, <code>limit="20"</code>', 'psyerns-framework' ) ); ?></p>
	</div>

	<?php
	$status = get_transient( 'pf_server_status' );
	if ( $status ) :
	?>
	<div class="pf-status-card">
		<h3><?php esc_html_e( 'Server Status', 'psyerns-framework' ); ?></h3>
		<div class="pf-status-grid">
			<div><strong><?php esc_html_e( 'Server:', 'psyerns-framework' ); ?></strong> <?php echo esc_html( $status['serverName'] ?? '—' ); ?></div>
			<div><strong><?php esc_html_e( 'Players:', 'psyerns-framework' ); ?></strong> <?php echo intval( $status['playerCount'] ?? 0 ); ?></div>
			<div><strong><?php esc_html_e( 'Map:', 'psyerns-framework' ); ?></strong> <?php echo esc_html( $status['mapName'] ?? '—' ); ?></div>
			<div><strong><?php esc_html_e( 'Day Time:', 'psyerns-framework' ); ?></strong> <?php echo esc_html( $status['dayTime'] ?? '—' ); ?></div>
			<div><strong><?php esc_html_e( 'Uptime:', 'psyerns-framework' ); ?></strong> <?php echo intval( ( $status['uptimeSeconds'] ?? 0 ) / 60 ); ?> min</div>
			<div><strong><?php esc_html_e( 'Last Update:', 'psyerns-framework' ); ?></strong> <?php echo esc_html( $status['received_at'] ?? '—' ); ?></div>
		</div>
	</div>
	<?php endif; ?>

	<form method="post" action="options.php">
		<?php
		settings_fields( 'pf_settings' );
		do_settings_sections( 'pf-settings' );
		submit_button();
		?>
	</form>
</div>
