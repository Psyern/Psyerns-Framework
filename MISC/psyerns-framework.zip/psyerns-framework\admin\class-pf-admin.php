<?php
/**
 * Admin menu, settings page and whitelist management.
 *
 * @package Psyerns_Framework
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class PF_Admin
 *
 * Registers admin menu pages, settings fields and whitelist CRUD actions.
 * Hooks are registered via init(), not in the constructor.
 */
class PF_Admin {

	/**
	 * Register all admin hooks.
	 *
	 * @return void
	 */
	public function init() {
		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_init', array( $this, 'handle_whitelist_actions' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	/**
	 * Register admin menu and subpages.
	 *
	 * @return void
	 */
	public function register_menu() {
		add_menu_page(
			__( 'Psyerns Framework', 'psyerns-framework' ),
			__( 'Psyerns Framework', 'psyerns-framework' ),
			'manage_options',
			'pf-settings',
			array( $this, 'render_settings_page' ),
			'dashicons-shield',
			80
		);

		add_submenu_page(
			'pf-settings',
			__( 'Whitelist', 'psyerns-framework' ),
			__( 'Whitelist', 'psyerns-framework' ),
			'manage_options',
			'pf-whitelist',
			array( $this, 'render_whitelist_page' )
		);
	}

	/**
	 * Register plugin settings via Settings API.
	 *
	 * @return void
	 */
	public function register_settings() {
		register_setting( 'pf_settings', 'pf_api_key', array(
			'sanitize_callback' => 'sanitize_text_field',
		) );
		register_setting( 'pf_settings', 'pf_steam_api_key', array(
			'sanitize_callback' => 'sanitize_text_field',
		) );
		add_settings_section(
			'pf_api_section',
			__( 'API Configuration', 'psyerns-framework' ),
			null,
			'pf-settings'
		);

		add_settings_field(
			'pf_api_key',
			__( 'API Key', 'psyerns-framework' ),
			array( $this, 'render_api_key_field' ),
			'pf-settings',
			'pf_api_section'
		);

		add_settings_field(
			'pf_steam_api_key',
			__( 'Steam API Key', 'psyerns-framework' ),
			array( $this, 'render_steam_key_field' ),
			'pf-settings',
			'pf_api_section'
		);

	}

	/**
	 * Render API Key settings field.
	 *
	 * @return void
	 */
	public function render_api_key_field() {
		$val = esc_attr( get_option( 'pf_api_key', '' ) );
		echo '<input type="text" id="pf_api_key" name="pf_api_key" value="' . $val . '" class="regular-text" />';
		echo '<p class="description">' . esc_html__( 'Shared secret between DayZ server and this plugin.', 'psyerns-framework' ) . '</p>';
	}

	/**
	 * Render Steam API Key settings field.
	 *
	 * @return void
	 */
	public function render_steam_key_field() {
		$val = esc_attr( get_option( 'pf_steam_api_key', '' ) );
		echo '<input type="text" id="pf_steam_api_key" name="pf_steam_api_key" value="' . $val . '" class="regular-text" />';
		echo '<p class="description">' . wp_kses_post( __( 'Optional. Used for Steam avatar resolution. Get your key at <a href="https://steamcommunity.com/dev/apikey" target="_blank">steamcommunity.com/dev/apikey</a>', 'psyerns-framework' ) ) . '</p>';
	}

	/**
	 * Render the settings page.
	 *
	 * @return void
	 */
	public function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		include PF_PLUGIN_DIR . 'admin/views/settings-page.php';
	}

	/**
	 * Render the whitelist management page.
	 *
	 * @return void
	 */
	public function render_whitelist_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		include PF_PLUGIN_DIR . 'admin/views/whitelist-page.php';
	}

	/**
	 * Process whitelist add/remove form submissions.
	 *
	 * @return void
	 */
	public function handle_whitelist_actions() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( isset( $_POST['pf_whitelist_add'] ) ) {
			check_admin_referer( 'pf_whitelist_add_nonce' );
			global $wpdb;
			$table    = PF_Database::get_table_name( 'whitelist' );
			$steam_id = sanitize_text_field( wp_unslash( $_POST['steam_id'] ?? '' ) );
			$name     = sanitize_text_field( wp_unslash( $_POST['player_name'] ?? '' ) );

			if ( ! empty( $steam_id ) ) {
				$wpdb->query( $wpdb->prepare(
					"INSERT IGNORE INTO {$table} (steam_id, name, added_at) VALUES (%s, %s, %s)",
					$steam_id,
					$name,
					current_time( 'mysql' )
				) );
			}

			wp_safe_redirect( admin_url( 'admin.php?page=pf-whitelist&msg=added' ) );
			exit;
		}

		if ( isset( $_POST['pf_whitelist_remove'] ) ) {
			check_admin_referer( 'pf_whitelist_remove_nonce' );
			global $wpdb;
			$table    = PF_Database::get_table_name( 'whitelist' );
			$steam_id = sanitize_text_field( wp_unslash( $_POST['steam_id'] ?? '' ) );

			if ( ! empty( $steam_id ) ) {
				$wpdb->delete( $table, array( 'steam_id' => $steam_id ) );
			}

			wp_safe_redirect( admin_url( 'admin.php?page=pf-whitelist&msg=removed' ) );
			exit;
		}
	}

	/**
	 * Enqueue admin CSS on plugin pages only.
	 *
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public function enqueue_assets( $hook ) {
		if ( false === strpos( $hook, 'pf-' ) ) {
			return;
		}
		wp_enqueue_style( 'pf-admin', PF_PLUGIN_URL . 'admin/css/pf-admin.css', array(), PF_VERSION );
	}
}
