<?php
/**
 * Main bootstrapper for the leaderboard system.
 *
 * @package Psyerns_Framework
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Psyern_Main
 *
 * Initializes all leaderboard hooks. No hooks in the constructor.
 */
class Psyern_Main {

	/**
	 * Register all hooks.
	 *
	 * @return void
	 */
	public function init() {
		// REST API.
		add_action( 'rest_api_init', array( $this, 'register_api' ) );

		// Shortcodes.
		add_action( 'init', array( $this, 'register_shortcodes' ) );

		// Admin.
		if ( is_admin() ) {
			$admin = new Psyern_Admin();
			$admin->init();
		}

		// AJAX handlers (logged in + public).
		add_action( 'wp_ajax_psyern_get_leaderboard', array( $this, 'ajax_get_leaderboard' ) );
		add_action( 'wp_ajax_nopriv_psyern_get_leaderboard', array( $this, 'ajax_get_leaderboard' ) );
	}

	/**
	 * Register leaderboard REST routes.
	 *
	 * @return void
	 */
	public function register_api() {
		$api = new Psyern_Api();
		$api->register_routes();
	}

	/**
	 * Register shortcodes.
	 *
	 * @return void
	 */
	public function register_shortcodes() {
		$sc = new Psyern_Shortcode();
		$sc->register();
	}

	/**
	 * AJAX handler for leaderboard data (mode switch without reload).
	 *
	 * @return void
	 */
	public function ajax_get_leaderboard() {
		check_ajax_referer( 'psyern_leaderboard_nonce', 'nonce' );

		$mode  = sanitize_text_field( wp_unslash( $_GET['mode'] ?? 'pvp' ) );
		$limit = min( absint( $_GET['limit'] ?? 10 ), 100 );

		$players = Psyern_Database::get_leaderboard( $mode, $limit );

		wp_send_json_success( array(
			'mode'    => $mode,
			'players' => $players,
		) );
	}
}
