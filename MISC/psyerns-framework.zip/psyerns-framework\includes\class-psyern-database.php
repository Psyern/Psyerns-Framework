<?php
/**
 * Leaderboard database schema and CRUD.
 *
 * @package Psyerns_Framework
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Psyern_Database
 *
 * Manages the leaderboard and weekly winners tables.
 */
class Psyern_Database {

	/**
	 * Get prefixed table name.
	 *
	 * @param string $name Short name.
	 * @return string Full table name.
	 */
	public static function table( $name ) {
		global $wpdb;
		return $wpdb->prefix . 'psyern_' . $name;
	}

	/**
	 * Create leaderboard tables via dbDelta.
	 *
	 * @return void
	 */
	public static function create_tables() {
		global $wpdb;
		$charset = $wpdb->get_charset_collate();
		$lb      = self::table( 'leaderboard' );
		$ww      = self::table( 'weekly_winners' );

		$sql = "CREATE TABLE {$lb} (
			id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
			steam_id VARCHAR(20) NOT NULL DEFAULT '',
			player_name VARCHAR(255) NOT NULL DEFAULT '',
			kills INT DEFAULT 0,
			deaths INT DEFAULT 0,
			kd_ratio FLOAT DEFAULT 0,
			playtime_seconds INT DEFAULT 0,
			mode VARCHAR(10) NOT NULL DEFAULT 'pvp',
			score INT DEFAULT 0,
			week_number INT DEFAULT 0,
			year INT DEFAULT 0,
			avatar_url VARCHAR(512) DEFAULT '',
			last_updated DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
			UNIQUE KEY steam_mode (steam_id, mode)
		) {$charset};

		CREATE TABLE {$ww} (
			id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
			steam_id VARCHAR(20) NOT NULL DEFAULT '',
			player_name VARCHAR(255) NOT NULL DEFAULT '',
			kills INT DEFAULT 0,
			deaths INT DEFAULT 0,
			kd_ratio FLOAT DEFAULT 0,
			score INT DEFAULT 0,
			mode VARCHAR(10) NOT NULL DEFAULT 'pvp',
			rank_position TINYINT DEFAULT 0,
			week_number INT DEFAULT 0,
			year INT DEFAULT 0,
			avatar_url VARCHAR(512) DEFAULT '',
			archived_at DATETIME DEFAULT CURRENT_TIMESTAMP
		) {$charset};";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );
	}

	/**
	 * Upsert a player row by steam_id + mode.
	 *
	 * @param array $player Player data array.
	 * @return void
	 */
	public static function upsert_player( $player ) {
		global $wpdb;
		$table    = self::table( 'leaderboard' );
		$steam_id = sanitize_text_field( $player['steamId'] ?? '' );
		$mode     = sanitize_text_field( $player['mode'] ?? 'pvp' );

		if ( empty( $steam_id ) ) {
			return;
		}

		$kills  = absint( $player['kills'] ?? 0 );
		$deaths = absint( $player['deaths'] ?? 0 );

		$row = array(
			'steam_id'         => $steam_id,
			'player_name'      => sanitize_text_field( $player['playerName'] ?? '' ),
			'kills'            => $kills,
			'deaths'           => $deaths,
			'kd_ratio'         => ( $deaths > 0 ) ? round( $kills / $deaths, 2 ) : (float) $kills,
			'playtime_seconds' => absint( $player['playtimeSeconds'] ?? 0 ),
			'mode'             => $mode,
			'score'            => absint( $player['score'] ?? 0 ),
			'week_number'      => absint( gmdate( 'W' ) ),
			'year'             => absint( gmdate( 'Y' ) ),
			'avatar_url'       => esc_url_raw( $player['avatarUrl'] ?? '' ),
		);

		$existing = $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$table} WHERE steam_id = %s AND mode = %s",
			$steam_id,
			$mode
		) );

		if ( null !== $existing ) {
			$wpdb->update( $table, $row, array( 'id' => $existing ) );
		} else {
			$wpdb->insert( $table, $row );
		}
	}

	/**
	 * Get leaderboard rows.
	 *
	 * @param string $mode  'pvp' or 'pve'.
	 * @param int    $limit Max rows.
	 * @return array
	 */
	public static function get_leaderboard( $mode = 'pvp', $limit = 20 ) {
		global $wpdb;
		$table = self::table( 'leaderboard' );

		return $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$table} WHERE mode = %s ORDER BY score DESC, kills DESC LIMIT %d",
			$mode,
			$limit
		), ARRAY_A );
	}

	/**
	 * Get top 3 players for the current week.
	 *
	 * @param string $mode 'pvp' or 'pve'.
	 * @return array
	 */
	public static function get_top3( $mode = 'pvp' ) {
		global $wpdb;
		$table = self::table( 'leaderboard' );
		$week  = absint( gmdate( 'W' ) );
		$year  = absint( gmdate( 'Y' ) );

		return $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$table} WHERE mode = %s AND week_number = %d AND year = %d ORDER BY score DESC, kills DESC LIMIT 3",
			$mode,
			$week,
			$year
		), ARRAY_A );
	}

	/**
	 * Drop plugin tables.
	 *
	 * @return void
	 */
	public static function drop_tables() {
		global $wpdb;
		// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared
		$wpdb->query( 'DROP TABLE IF EXISTS ' . self::table( 'leaderboard' ) );
		$wpdb->query( 'DROP TABLE IF EXISTS ' . self::table( 'weekly_winners' ) );
		// phpcs:enable
	}
}
