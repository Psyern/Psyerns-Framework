/**
 * Psyern Leaderboard v2 — Frontend JavaScript
 *
 * Handles mode switching (PvP/PvE), limit toggle,
 * AJAX data loading, staggered row animations, auto-refresh.
 * Includes: Faction Badges, Boss Kills, Reputation, Faction Bar.
 *
 * @package Psyerns_Framework
 */
(function() {
	'use strict';

	var config = window.psyernConfig || {};

	function init() {
		var els = document.querySelectorAll('.psyern-lb[data-mode]');
		for (var i = 0; i < els.length; i++) {
			initInstance(els[i]);
		}
	}

	function initInstance(el) {
		var state = {
			el: el,
			mode: el.getAttribute('data-mode') || 'pvp',
			limit: parseInt(el.getAttribute('data-limit'), 10) || 10,
			refreshInterval: parseInt(el.getAttribute('data-refresh'), 10) || 60000,
		};

		bindModeButtons(state);
		bindLimitButtons(state);
		loadData(state);

		if (state.refreshInterval > 0) {
			setInterval(function() { loadData(state); }, state.refreshInterval);
		}
	}

	function bindModeButtons(state) {
		var btns = state.el.querySelectorAll('.psyern-lb__mode-btn');
		for (var i = 0; i < btns.length; i++) {
			btns[i].addEventListener('click', function(e) {
				e.preventDefault();
				var newMode = this.getAttribute('data-mode');
				if (newMode === state.mode) return;
				state.mode = newMode;
				var all = state.el.querySelectorAll('.psyern-lb__mode-btn');
				for (var j = 0; j < all.length; j++) {
					all[j].classList.toggle('active', all[j].getAttribute('data-mode') === newMode);
				}
				loadData(state);
			});
		}
	}

	function bindLimitButtons(state) {
		var btns = state.el.querySelectorAll('.psyern-lb__limit-btn');
		for (var i = 0; i < btns.length; i++) {
			btns[i].addEventListener('click', function(e) {
				e.preventDefault();
				var newLimit = parseInt(this.getAttribute('data-limit'), 10);
				if (newLimit === state.limit) return;
				state.limit = newLimit;
				var all = state.el.querySelectorAll('.psyern-lb__limit-btn');
				for (var j = 0; j < all.length; j++) {
					all[j].classList.toggle('active', parseInt(all[j].getAttribute('data-limit'), 10) === newLimit);
				}
				loadData(state);
			});
		}
	}

	function loadData(state) {
		var url = config.ajaxUrl +
			'?action=psyern_get_leaderboard' +
			'&mode=' + encodeURIComponent(state.mode) +
			'&limit=' + state.limit +
			'&nonce=' + encodeURIComponent(config.nonce);

		var tbody = state.el.querySelector('.psyern-lb__table tbody');
		if (!tbody) return;

		fetch(url)
			.then(function(res) { return res.json(); })
			.then(function(json) {
				if (!json.success || !json.data || !json.data.players) return;
				renderRows(tbody, json.data.players, state);
				renderFactionBar(state.el, json.data);
			})
			.catch(function() {
				tbody.innerHTML = '<tr><td colspan="10" class="psyern-lb__loading">' +
					escHtml(config.i18n ? config.i18n.error : 'Error') + '</td></tr>';
			});
	}

	function renderRows(tbody, players, state) {
		var html = '';
		for (var i = 0; i < players.length; i++) {
			var p = players[i];
			var rank = i + 1;
			var pt = formatPlaytime(parseInt(p.playtime_seconds, 10) || 0);
			var bk = p.war_boss_kills || 0;
			var rep = p.hardline_reputation || 0;

			html += '<tr style="animation-delay:' + (i * 0.05) + 's">';
			html += '<td class="psyern-lb__rank">' + rank + '</td>';
			html += '<td>';
			if (p.avatar_url) {
				html += '<img class="psyern-lb__avatar" src="' + escHtml(p.avatar_url) + '" alt="" loading="lazy" />';
			}
			html += '</td>';
			html += '<td class="psyern-lb__name">' + escHtml(p.player_name) + factionBadge(p.war_faction) + '</td>';
			html += '<td>' + fmtN(p.kills) + '</td>';
			html += '<td>' + fmtN(p.deaths) + '</td>';
			html += '<td class="psyern-lb__kd">' + (parseFloat(p.kd_ratio) || 0).toFixed(2) + '</td>';
			html += '<td class="psyern-lb__boss-kills">' + (bk > 0 ? bk : '') + '</td>';
			html += '<td class="psyern-lb__reputation">' + (rep > 0 ? fmtN(rep) : '') + '</td>';
			html += '<td class="psyern-lb__playtime">' + pt + '</td>';
			html += '</tr>';
		}

		if (0 === players.length) {
			html = '<tr><td colspan="10" class="psyern-lb__loading">' +
				escHtml(config.i18n ? config.i18n.loading : 'No data') + '</td></tr>';
		}

		tbody.innerHTML = html;
	}

	function renderFactionBar(el, data) {
		var existing = el.querySelector('.psyern-lb__faction-bar');
		if (existing) existing.remove();

		var east = parseInt(data.globalEastPoints, 10) || 0;
		var west = parseInt(data.globalWestPoints, 10) || 0;
		var total = east + west;
		if (total === 0) return;

		var ePct = Math.round((east / total) * 100);
		var wPct = 100 - ePct;

		var bar = document.createElement('div');
		bar.className = 'psyern-lb__faction-bar';
		bar.innerHTML = '<span class="psyern-lb__faction-label-east">EAST ' + fmtN(east) + '</span>' +
			'<div class="psyern-lb__faction-bar-track">' +
			'<div class="psyern-lb__faction-bar-east" style="width:' + ePct + '%"></div>' +
			'<div class="psyern-lb__faction-bar-west" style="width:' + wPct + '%"></div>' +
			'</div>' +
			'<span class="psyern-lb__faction-label-west">' + fmtN(west) + ' WEST</span>';

		var header = el.querySelector('.psyern-lb__header');
		if (header && header.nextSibling) {
			header.parentNode.insertBefore(bar, header.nextSibling);
		}
	}

	function factionBadge(faction) {
		if (!faction || faction === '') return '';
		var f = faction.toUpperCase();
		var cls = 'psyern-lb__faction--neutral';
		if (f === 'EAST') cls = 'psyern-lb__faction--east';
		if (f === 'WEST') cls = 'psyern-lb__faction--west';
		return ' <span class="psyern-lb__faction ' + cls + '">' + escHtml(f) + '</span>';
	}

	function formatPlaytime(seconds) {
		var h = Math.floor(seconds / 3600);
		var m = Math.floor((seconds % 3600) / 60);
		return h + 'h ' + m + 'm';
	}

	function fmtN(n) {
		return Number(n || 0).toLocaleString();
	}

	function escHtml(s) {
		var div = document.createElement('div');
		div.appendChild(document.createTextNode(s || ''));
		return div.innerHTML;
	}

	if ('loading' === document.readyState) {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}
})();
